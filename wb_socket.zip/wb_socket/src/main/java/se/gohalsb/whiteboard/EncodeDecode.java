package se.gohalsb.whiteboard;

import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.stream.JsonGenerator;
import javax.websocket.DecodeException;
import javax.websocket.Decoder;
import javax.websocket.EncodeException;
import javax.websocket.Encoder;
import javax.websocket.EndpointConfig;

public class EncodeDecode implements Decoder.Text<MyMessage>, Encoder.Text<MyMessage>{

	@Override
	public void destroy() {
		System.out.println("destroy called on chatdecoder");		
	}

	@Override
	public void init(EndpointConfig config) {
		System.out.println("init called on chatdecoder");	
	}

	@Override
	public String encode(MyMessage object) throws EncodeException {
		 System.out.println("I have to encode " + object);
		 StringWriter sw = new StringWriter();
		 JsonGenerator generator = Json.createGenerator(sw);
		 generator.writeStartObject();
		 generator.write("text", ((MyMessage)object).getText());
		 generator.writeEnd();
		 generator.flush();
		 String answer = sw.toString();
		 System.out.println("I encoded an object: " + answer);
		 return answer;
	}

	@Override
	public MyMessage decode(String txt) throws DecodeException {
		 System.out.println("Entra al decode para hacer " + txt);
		 Reader reader = new StringReader(txt);
		 JsonReader jsonReader = Json.createReader(reader);
		 JsonObject object = jsonReader.readObject();
		 String text = object.getJsonString("text").getString();
		 System.out.println("Entra al decode y sale con " + text);
		 return new MyMessage (text);
	}

	@Override
	public boolean willDecode(String s) {
		System.out.println("Will decode asked for " + s);
		return true;
	}

}
