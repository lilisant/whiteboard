package se.gohalsb.whiteboard;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.websocket.CloseReason;
import javax.websocket.EncodeException;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.*;

import org.json.JSONArray;
import org.json.JSONObject;

//@ServerEndpoint(value="/shout", encoders = {Encode.class}, decoders = {Decode.class})
@ServerEndpoint(value="/shout", decoders=EncodeDecode.class, encoders=EncodeDecode.class)
//@ServerEndpoint("/shout")
public class WebSocketEndPoint {
	//  private static Set<Session> peers = Collections.synchronizedSet(new HashSet<Session>());
	 private static List<Session> sessions = Collections.synchronizedList(new ArrayList<Session>());

	@OnOpen
	public void myOnOpen(Session session) {
		System.out.println("Client connected");
		try {
			session.getBasicRemote().sendText("Hello!");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@OnMessage
	public void onMessage (MyMessage msg, Session s) throws IOException, EncodeException {
	//public void myOnMessage (Session s, String msg) throws IOException, EncodeException {	
	 System.out.println("viene aki: " + msg);
		 for (Session session : sessions) { // loop over active sessions and send the message.
		 session.getBasicRemote().sendObject(msg);
		 }

	 }
 /*  
   public void broadcastFigure(Model model, Session session) throws IOException, EncodeException {
       System.out.println("broadcastFigure: " + model);
       for (Session peer : peers) {
           if (!peer.equals(session)) {
               peer.getBasicRemote().sendObject(model);
           }
       }
   }
	public void myOnMessage(Session session, Model model) throws EncodeException {
		
		 System.out.println("viene aki");
		
		//String result = Controller.checkForCommand(model);

		
		try {

			for (Session s : session.getOpenSessions()) {

				if (s.isOpen()) {
					if (!session.equals(s)) { // no se debe poner (session != s)
						s.getBasicRemote().sendObject(model); 
						//s.getBasicRemote().sendText("[{\"cmd\":\"update\"}]"); // s.getAsyncRemote().sendText(message);
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Message Received: " + model);
	}
*/
	@OnClose
	public void myOnClose(Session session, CloseReason reason) {
		System.out.println("Client closed");
	}

	@OnError
	public void myOnError(Session session, Throwable trowable) {
		System.out.println("Client Error");
	}
}