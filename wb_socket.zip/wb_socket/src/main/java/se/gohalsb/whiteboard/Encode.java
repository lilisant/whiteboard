package se.gohalsb.whiteboard;

import javax.websocket.EncodeException;
import javax.websocket.Encoder;
import javax.websocket.EndpointConfig;

public class Encode implements Encoder.Text<Model> {

	@Override
	public void destroy() {
		 System.out.println("destroy");
	}

	@Override
	public void init(EndpointConfig arg0) {
		System.out.println("init");
	}

	@Override
	public String encode(Model model) throws EncodeException {
		return model.getJson().toString();
	}

}
