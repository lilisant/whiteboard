package se.gohalsb.whiteboard;

public class MyMessage {
	private String text;
	public MyMessage(String text) {
	super();
	this.text = text;
	}
	public String getText() {
	return text;
	}
	public void setText(String text) {
	this.text = text;
	}
	@Override
	public String toString() {
	return "MyMessage [text=" + text + "]";
	}
}
