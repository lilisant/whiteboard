package se.gohalsb.whiteboard;

import java.util.ArrayList;
import java.util.List;

import org.json.*;


public class Controller {

	static List<Model> items = new ArrayList<Model>();
	//static Model item = new Model(0);
	
	public void jsonTest() {
		String jsonString = "{\"cmd\":\"update\","
				+ "\"post\":{"
				+ "\"id\":\"1\","
				+ "\"title\":\"En första post\","
				+ "\"Description\":\"\","
				+ "\"name\":\"goha\","
				+ "\"color\":\"#fffb00\","
				+ "\"category\":\"One\","
				+ "\"done\":\"false\""
				+ "}}";
				
		JSONObject jsonObjectCmd = new JSONObject(jsonString);
		JSONObject newJSON = jsonObjectCmd.getJSONObject("post");
		System.out.println("newJSON-->" + newJSON + "<--");
		JSONObject jsonObjectData = new JSONObject(newJSON.toString());
		System.out.println("id -->" + jsonObjectData.getString("id")+"<--");
		System.out.println("category-->" + jsonObjectData.getString("category") + "<--");

	}
	    	
	public static String checkForCommand(String st) {
		// Decode our JSON
        String result = null;
		String jsonString = "{\"cmd\":\"update\","
				+ "\"post\":{"
				+ "\"id\":\"1\","
				+ "\"title\":\"En första post\","
				+ "\"Description\":\"\","
				+ "\"name\":\"goha\","
				+ "\"color\":\"#fffb00\","
				+ "\"category\":\"One\","
				+ "\"done\":\"false\""
				+ "}}";
				
		JSONObject jsonObjectCmd = new JSONObject(jsonString);
		JSONObject newJSON = jsonObjectCmd.getJSONObject("post");
		System.out.println("newJSON-->" + newJSON + "<--");
		JSONObject jsonObjectData = new JSONObject(newJSON.toString());
		System.out.println("id -->" + jsonObjectData.getString("id")+"<--");
		System.out.println("category-->" + jsonObjectData.getString("category") + "<--");

        

        //result = (String) jsonObject.getJSONArray("argv");
        
		String string [] = null;
		string[0] = "cmd";
		string[0] = st;
		if (string[0].equalsIgnoreCase("cmd")) {
			// we have a command
			if (string[1].equalsIgnoreCase("delete")) {
				// do a delete with the trailing id.
				items.remove(Integer.parseInt(string[3]));
			} else if (string[1].equalsIgnoreCase("create")) {
				// add a post (to the end) with the trailing JSON
				/*
				item.setTitle("");
				item.setDescription("");
				item.setName("");
				item.setColor("");
				item.setCategory("");
				item.setDone("");
				*/
			} else if (string[1].equalsIgnoreCase("update")) {
				// update our object with the rest of JSON

			} else if (string[1].equalsIgnoreCase("getall")) {
				// send the whole object converted to JSON
			}
		}
		return result;
	}
}
