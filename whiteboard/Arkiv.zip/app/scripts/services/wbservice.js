'use strict';

/**
 * @ngdoc service
 * @name whiteboardApp.wbservice
 * @description
 * # wbservice
 * Factory in the whiteboardApp.
 */

angular.module('whiteboardApp')
  .factory('wbservice', function ($scope) {
    // Service logic
    // ...

    var ws;


    ws = new WebSocket('ws://localhost:8080/whiteboard/whiteboard');

    ws.onopen = function () {
      console.log('Socket has been opened!');
    };

    ws.onmessage = function (message) {
      console.log(message);
      $scope.items = JSON.parse(message.data);
    };

    // Public API here
    return {
      create: function (newItem) {

        var request = {
          'type': 'put',
          'data': newItem
        };
        ws.send(JSON.stringify(request));
      },
      getAll: function () {
        console.log($scope.socketIsOpen);
        var request = {
          'type': 'getAll',
          'data': null
        };
        // Storing in a variable for clarity on what sendRequest returns
        ws.send(JSON.stringify(request));
      }


    };
  });