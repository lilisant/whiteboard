window.addEventListener('DOMContentLoaded', function () {
	'use strict';

});