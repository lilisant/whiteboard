memoryDataService
=================

A memory web service in node for mimicing a standard rest service returning json 

